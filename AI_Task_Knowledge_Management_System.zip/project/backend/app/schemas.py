"""Pydantic request/response models (the API's public data contracts)."""
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, EmailStr, Field


# ---------------------------- Auth ----------------------------------------
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: int
    name: str


class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = "user"  # only an existing admin can create another admin (enforced in route)


# ---------------------------- Users ----------------------------------------
class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str

    class Config:
        from_attributes = True


# ---------------------------- Tasks ----------------------------------------
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    assigned_to: Optional[int] = None


class TaskStatusUpdate(BaseModel):
    status: str = Field(pattern="^(pending|completed)$")


class TaskOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    status: str
    assigned_to: Optional[int]
    created_by: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------------------------- Documents -------------------------------------
class DocumentOut(BaseModel):
    id: int
    title: str
    filename: str
    content_type: str
    uploaded_by: int
    uploaded_at: datetime

    class Config:
        from_attributes = True


# ---------------------------- Search ----------------------------------------
class SearchRequest(BaseModel):
    query: str
    top_k: int = 5


class SearchResultItem(BaseModel):
    document_id: int
    document_title: str
    chunk_text: str
    score: float


class SearchResponse(BaseModel):
    query: str
    results: List[SearchResultItem]


# ---------------------------- Analytics -------------------------------------
class TopQuery(BaseModel):
    query_text: str
    count: int


class AnalyticsResponse(BaseModel):
    total_tasks: int
    completed_tasks: int
    pending_tasks: int
    total_documents: int
    total_users: int
    most_searched_queries: List[TopQuery]
