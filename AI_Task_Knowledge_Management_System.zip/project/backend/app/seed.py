"""
Idempotent startup seeding: makes sure the 'admin' and 'user' roles exist
and that a default admin account is available so you can log in on a
completely fresh database without a manual SQL step.
"""
from sqlalchemy.orm import Session

from app import models
from app.security import hash_password
from app.config import ROLE_ADMIN, ROLE_USER, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD


def seed_roles(db: Session) -> None:
    for role_name in (ROLE_ADMIN, ROLE_USER):
        exists = db.query(models.Role).filter(models.Role.name == role_name).first()
        if not exists:
            db.add(models.Role(name=role_name))
    db.commit()


def seed_default_admin(db: Session) -> None:
    existing_admin = db.query(models.User).filter(models.User.email == DEFAULT_ADMIN_EMAIL).first()
    if existing_admin:
        return

    admin_role = db.query(models.Role).filter(models.Role.name == ROLE_ADMIN).first()
    admin = models.User(
        name="Administrator",
        email=DEFAULT_ADMIN_EMAIL,
        hashed_password=hash_password(DEFAULT_ADMIN_PASSWORD),
        role_id=admin_role.id,
    )
    db.add(admin)
    db.commit()


def run_seed(db: Session) -> None:
    seed_roles(db)
    seed_default_admin(db)
