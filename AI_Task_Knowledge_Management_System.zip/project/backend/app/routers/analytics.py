from collections import Counter

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas
from app.dependencies import require_role
from app.config import ROLE_ADMIN

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("", response_model=schemas.AnalyticsResponse)
def get_analytics(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_role(ROLE_ADMIN)),
):
    """Admin-only dashboard numbers: task counts, KB size, and top searches."""
    total_tasks = db.query(models.Task).count()
    completed_tasks = db.query(models.Task).filter(models.Task.status == "completed").count()
    pending_tasks = total_tasks - completed_tasks
    total_documents = db.query(models.Document).count()
    total_users = db.query(models.User).count()

    all_queries = [q.query_text.strip().lower() for q in db.query(models.SearchQuery).all()]
    top_counts = Counter(all_queries).most_common(10)
    most_searched = [schemas.TopQuery(query_text=q, count=c) for q, c in top_counts]

    return schemas.AnalyticsResponse(
        total_tasks=total_tasks,
        completed_tasks=completed_tasks,
        pending_tasks=pending_tasks,
        total_documents=total_documents,
        total_users=total_users,
        most_searched_queries=most_searched,
    )
