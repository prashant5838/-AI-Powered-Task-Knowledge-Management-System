from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas
from app.dependencies import get_current_user, require_role
from app.services.logging_service import log_activity
from app.config import ROLE_ADMIN

router = APIRouter(prefix="/tasks", tags=["Tasks"])


@router.post("", response_model=schemas.TaskOut, status_code=status.HTTP_201_CREATED)
def create_task(
    payload: schemas.TaskCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_role(ROLE_ADMIN)),
):
    """Admin-only: create and optionally assign a task to a user."""
    if payload.assigned_to:
        assignee = db.query(models.User).filter(models.User.id == payload.assigned_to).first()
        if not assignee:
            raise HTTPException(status_code=404, detail="Assigned user not found")

    task = models.Task(
        title=payload.title,
        description=payload.description,
        assigned_to=payload.assigned_to,
        created_by=current_user.id,
    )
    db.add(task)
    db.commit()
    db.refresh(task)

    log_activity(db, current_user.id, "TASK_CREATE", f"Created task '{task.title}' (id={task.id})")
    return task


@router.get("", response_model=List[schemas.TaskOut])
def list_tasks(
    status_filter: Optional[str] = None,
    assigned_to: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Dynamic filtering API: /tasks?status=completed&assigned_to=1

    - Admins can see all tasks (optionally filtered).
    - Regular users only ever see their own tasks, regardless of the
      assigned_to filter, to keep RBAC enforced at the query level.
    """
    query = db.query(models.Task)

    if current_user.role.name != ROLE_ADMIN:
        query = query.filter(models.Task.assigned_to == current_user.id)
    elif assigned_to is not None:
        query = query.filter(models.Task.assigned_to == assigned_to)

    if status_filter is not None:
        if status_filter not in ("pending", "completed"):
            raise HTTPException(status_code=400, detail="status must be 'pending' or 'completed'")
        query = query.filter(models.Task.status == status_filter)

    return query.order_by(models.Task.created_at.desc()).all()


@router.patch("/{task_id}/status", response_model=schemas.TaskOut)
def update_task_status(
    task_id: int,
    payload: schemas.TaskStatusUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """A user can only update the status of tasks assigned to them (admins can update any)."""
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if current_user.role.name != ROLE_ADMIN and task.assigned_to != current_user.id:
        raise HTTPException(status_code=403, detail="You cannot update someone else's task")

    task.status = payload.status
    db.commit()
    db.refresh(task)

    log_activity(
        db, current_user.id, "TASK_UPDATE",
        f"Task id={task.id} status set to '{task.status}'",
    )
    return task
