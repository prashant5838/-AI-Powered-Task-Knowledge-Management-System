import os
import uuid
from typing import List

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas
from app.dependencies import get_current_user, require_role
from app.services.logging_service import log_activity
from app.services.search_service import search_engine
from app.config import UPLOAD_DIR, ROLE_ADMIN

router = APIRouter(prefix="/documents", tags=["Documents"])

ALLOWED_EXTENSIONS = {".txt"}  # PDF is optional per the spec; kept out of MVP scope


@router.post("", response_model=schemas.DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    title: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_role(ROLE_ADMIN)),
):
    """Admin-only: upload a .txt file into the knowledge base and index it for search."""
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Only .txt files are supported in this MVP")

    raw_bytes = await file.read()
    try:
        raw_text = raw_bytes.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be UTF-8 encoded text")

    stored_filename = f"{uuid.uuid4().hex}{ext}"
    stored_path = os.path.join(UPLOAD_DIR, stored_filename)
    with open(stored_path, "w", encoding="utf-8") as f:
        f.write(raw_text)

    document = models.Document(
        title=title,
        filename=file.filename,
        file_path=stored_path,
        content_type=file.content_type or "text/plain",
        uploaded_by=current_user.id,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    # Chunk + embed + index the new document straight away.
    search_engine.index_new_document(db, document, raw_text)

    log_activity(
        db, current_user.id, "DOCUMENT_UPLOAD",
        f"Uploaded document '{document.title}' (id={document.id})",
    )
    return document


@router.get("", response_model=List[schemas.DocumentOut])
def list_documents(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Any authenticated user can browse the knowledge-base document list."""
    return db.query(models.Document).order_by(models.Document.uploaded_at.desc()).all()
