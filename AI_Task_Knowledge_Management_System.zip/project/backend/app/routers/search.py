from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas
from app.dependencies import get_current_user
from app.services.search_service import search_engine
from app.services.logging_service import log_activity

router = APIRouter(prefix="/search", tags=["Search"])


@router.post("", response_model=schemas.SearchResponse)
def semantic_search(
    payload: schemas.SearchRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Embedding-based semantic search over the knowledge base:
    query text -> TF-IDF embedding -> cosine similarity in the vector
    store -> top-k most relevant document chunks.
    """
    raw_results = search_engine.search(db, payload.query, top_k=payload.top_k)

    # Persist the query for the "most searched queries" analytic, and audit log it.
    db.add(models.SearchQuery(user_id=current_user.id, query_text=payload.query))
    db.commit()
    log_activity(db, current_user.id, "SEARCH", f"Searched: '{payload.query}'")

    return schemas.SearchResponse(
        query=payload.query,
        results=[schemas.SearchResultItem(**r) for r in raw_results],
    )
