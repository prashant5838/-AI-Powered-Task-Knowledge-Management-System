from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas
from app.security import verify_password, hash_password, create_access_token
from app.services.logging_service import log_activity
from app.dependencies import require_role
from app.config import ROLE_ADMIN, ROLE_USER

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", response_model=schemas.TokenResponse)
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password"
        )

    token = create_access_token({"sub": str(user.id), "role": user.role.name})
    log_activity(db, user.id, "LOGIN", f"{user.email} logged in")

    return schemas.TokenResponse(
        access_token=token, role=user.role.name, user_id=user.id, name=user.name
    )


@router.post("/register", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED)
def register(
    payload: schemas.RegisterRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_role(ROLE_ADMIN)),
):
    """
    Only an existing admin can create new accounts (admin or user).
    This keeps RBAC enforced at account-creation time, not just afterwards.
    """
    existing = db.query(models.User).filter(models.User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    role = db.query(models.Role).filter(models.Role.name == payload.role).first()
    if not role:
        raise HTTPException(status_code=400, detail="Invalid role")

    user = models.User(
        name=payload.name,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role_id=role.id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return schemas.UserOut(id=user.id, name=user.name, email=user.email, role=role.name)
