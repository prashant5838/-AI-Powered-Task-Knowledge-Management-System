"""
Application entrypoint.

Creates tables (if they don't already exist), seeds roles/default admin,
warms up the semantic-search index from whatever is already in the DB,
and wires up all routers.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app import seed
from app.services.search_service import search_engine
from app.routers import auth, tasks, documents, search, analytics

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-Powered Task & Knowledge Management System",
    description="Admin uploads documents & assigns tasks; users semantically "
                "search the knowledge base and complete tasks.",
    version="1.0.0",
)

# Allow the React dev server (and any frontend) to call the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(tasks.router)
app.include_router(documents.router)
app.include_router(search.router)
app.include_router(analytics.router)


@app.on_event("startup")
def on_startup():
    db = SessionLocal()
    try:
        seed.run_seed(db)
        search_engine.rebuild(db)  # build vector index from any existing documents
    finally:
        db.close()


@app.get("/", tags=["Health"])
def health_check():
    return {
        "status": "ok",
        "service": "AI Task & Knowledge Management API",
        "vector_backend": search_engine.vector_store.backend_name,
    }
