"""Small helper to keep activity-log writes consistent across routers."""
from typing import Optional
from sqlalchemy.orm import Session

from app import models


def log_activity(db: Session, user_id: Optional[int], action: str, details: str = "") -> None:
    entry = models.ActivityLog(user_id=user_id, action=action, details=details)
    db.add(entry)
    db.commit()
