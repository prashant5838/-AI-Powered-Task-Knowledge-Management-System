"""
Embedding service
==================
Core AI requirement: convert text -> numeric vector ("embedding") WITHOUT
depending on an external LLM API. We implement this ourselves using a
TF-IDF vector space model (scikit-learn's feature-extraction primitives),
which is a well-established, fully local/offline way to turn text into
vectors that capture term importance and can be compared with cosine
similarity. This keeps the "core logic implemented, not just calling an
LLM API" requirement satisfied while remaining lightweight enough to run
without GPUs or downloaded model weights.

Design notes
------------
* The vectorizer is corpus-dependent (a TF-IDF vocabulary is built from
  all chunks seen so far), so it is retrained whenever new documents are
  added and persisted to disk (see vector_store.py) so search stays
  consistent across process restarts.
* Swap-in point: if you want transformer embeddings instead, replace
  `EmbeddingService.fit`/`embed` with a sentence-transformers model and
  keep the same interface -- the rest of the app does not need to change.
"""
import re
from typing import List

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


def simple_tokenize_preprocess(text: str) -> str:
    """Light cleanup before vectorizing: lowercase + strip extra whitespace."""
    text = text.lower()
    text = re.sub(r"\s+", " ", text).strip()
    return text


class EmbeddingService:
    """
    Wraps a TF-IDF vectorizer that is (re)fitted on the full corpus of
    document chunks. Produces dense float32 numpy vectors suitable for
    cosine-similarity search.
    """

    def __init__(self, max_features: int = 4096):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=(1, 2),
            stop_words="english",
            preprocessor=simple_tokenize_preprocess,
        )
        self._fitted = False

    def fit(self, corpus: List[str]) -> None:
        """(Re)build the vocabulary/IDF weights from every chunk in the KB."""
        if not corpus:
            self._fitted = False
            return
        self.vectorizer.fit(corpus)
        self._fitted = True

    def embed(self, texts: List[str]) -> np.ndarray:
        """Transform a list of texts into TF-IDF vectors (float32 ndarray)."""
        if not self._fitted:
            raise RuntimeError("EmbeddingService must be fit() before embed()")
        matrix = self.vectorizer.transform(texts)
        return matrix.toarray().astype("float32")

    def embed_query(self, query: str) -> np.ndarray:
        return self.embed([query])[0]

    @property
    def is_fitted(self) -> bool:
        return self._fitted


def chunk_text(text: str, max_words: int = 120, overlap: int = 20) -> List[str]:
    """
    Split a document into overlapping word-based chunks so that long
    documents are searchable at a paragraph-like granularity instead of
    only as one giant vector.
    """
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + max_words, len(words))
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        if end == len(words):
            break
        start = end - overlap  # overlap keeps context across chunk boundaries
    return chunks
