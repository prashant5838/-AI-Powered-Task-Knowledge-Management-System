"""
Search service
==============
Orchestrates the semantic-search pipeline end to end:

    document text -> chunks -> TF-IDF embeddings -> vector store -> query

Exposes a single module-level singleton (`search_engine`) so the same
in-memory index is reused across requests within one running process,
and a `rebuild()` method that is called whenever a document is
uploaded so the index always reflects the latest knowledge base.
"""
import pickle
from typing import List

import numpy as np
from sqlalchemy.orm import Session

from app import models
from app.services.embedding_service import EmbeddingService, chunk_text
from app.services.vector_store import VectorStore


class SearchEngine:
    def __init__(self):
        self.embedding_service = EmbeddingService()
        self.vector_store = VectorStore()

    def index_new_document(self, db: Session, document: models.Document, raw_text: str) -> None:
        """Chunk a freshly uploaded document and persist chunks (embeddings filled in on rebuild)."""
        pieces = chunk_text(raw_text)
        for i, piece in enumerate(pieces):
            db.add(
                models.DocumentChunk(
                    document_id=document.id,
                    chunk_index=i,
                    text=piece,
                )
            )
        db.commit()
        self.rebuild(db)

    def rebuild(self, db: Session) -> None:
        """
        Refit the TF-IDF vectorizer on every chunk in the DB, recompute all
        embeddings, persist them back to the chunk rows, and rebuild the
        in-memory vector index. Called after every upload so search always
        reflects the current knowledge base.
        """
        chunks = db.query(models.DocumentChunk).all()
        if not chunks:
            self.vector_store.build([], np.zeros((0, 1), dtype="float32"))
            return

        texts = [c.text for c in chunks]
        self.embedding_service.fit(texts)
        vectors = self.embedding_service.embed(texts)

        for chunk, vector in zip(chunks, vectors):
            chunk.embedding = pickle.dumps(vector)
        db.commit()

        chunk_ids = [c.id for c in chunks]
        self.vector_store.build(chunk_ids, vectors)

    def search(self, db: Session, query: str, top_k: int = 5):
        if not self.embedding_service.is_fitted:
            self.rebuild(db)
        if not self.embedding_service.is_fitted:
            return []  # empty knowledge base

        query_vector = self.embedding_service.embed_query(query)
        hits = self.vector_store.search(query_vector, top_k=top_k)

        results = []
        for chunk_id, score in hits:
            chunk = db.query(models.DocumentChunk).filter(models.DocumentChunk.id == chunk_id).first()
            if chunk is None:
                continue
            results.append(
                {
                    "document_id": chunk.document_id,
                    "document_title": chunk.document.title,
                    "chunk_text": chunk.text,
                    "score": round(score, 4),
                }
            )
        return results


# Module-level singleton reused across requests in this process.
search_engine = SearchEngine()
