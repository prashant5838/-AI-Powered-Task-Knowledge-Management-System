"""
Vector store
============
Stores chunk embeddings and performs similarity search.

We try to use FAISS (Facebook AI Similarity Search) if the `faiss-cpu`
package is installed, since the assignment explicitly calls it out.
If FAISS isn't available in the environment, we transparently fall back
to an equivalent brute-force cosine-similarity search implemented with
numpy. Both paths expose the exact same `add`/`search` interface, so the
rest of the application is completely unaware of which backend is active.

To enable FAISS: `pip install faiss-cpu` (already listed as optional in
requirements.txt) - no code changes needed, it is auto-detected below.
"""
from typing import List, Tuple
import numpy as np

try:
    import faiss  # type: ignore
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False


def _normalize(vectors: np.ndarray) -> np.ndarray:
    """L2-normalize rows so that inner product == cosine similarity."""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1e-10
    return vectors / norms


class VectorStore:
    """
    In-memory vector index rebuilt from the database on startup / whenever
    a new document is added. `ids` keeps track of the DocumentChunk primary
    key each row of the index corresponds to.
    """

    def __init__(self, dim: int = None):
        self.dim = dim
        self.ids: List[int] = []
        self._np_matrix: np.ndarray = None  # normalized vectors, fallback backend
        self._faiss_index = None

    def build(self, chunk_ids: List[int], vectors: np.ndarray) -> None:
        """Build the index from scratch given all chunk ids + their vectors."""
        self.ids = list(chunk_ids)
        if vectors.shape[0] == 0:
            self._np_matrix = None
            self._faiss_index = None
            return

        self.dim = vectors.shape[1]
        normalized = _normalize(vectors.astype("float32"))

        if FAISS_AVAILABLE:
            index = faiss.IndexFlatIP(self.dim)  # inner product on normalized vecs = cosine
            index.add(normalized)
            self._faiss_index = index
            self._np_matrix = None
        else:
            self._np_matrix = normalized
            self._faiss_index = None

    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Tuple[int, float]]:
        """Return [(chunk_id, similarity_score), ...] sorted best-first."""
        if (self._faiss_index is None and self._np_matrix is None) or not self.ids:
            return []

        query = _normalize(query_vector.reshape(1, -1).astype("float32"))

        if FAISS_AVAILABLE and self._faiss_index is not None:
            scores, indices = self._faiss_index.search(query, min(top_k, len(self.ids)))
            results = [
                (self.ids[idx], float(score))
                for idx, score in zip(indices[0], scores[0])
                if idx != -1
            ]
        else:
            # Brute-force cosine similarity via matrix multiply.
            sims = self._np_matrix @ query[0]
            top_indices = np.argsort(-sims)[:top_k]
            results = [(self.ids[i], float(sims[i])) for i in top_indices]

        return results

    @property
    def backend_name(self) -> str:
        return "faiss" if FAISS_AVAILABLE else "numpy-cosine (faiss fallback)"
