// Thin fetch() wrapper: attaches the JWT, builds query strings, and
// normalizes error handling so components stay simple.

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

function getToken() {
  return localStorage.getItem("access_token");
}

async function request(path, { method = "GET", body, params, isForm = false } = {}) {
  let url = `${API_BASE_URL}${path}`;
  if (params) {
    const query = Object.entries(params)
      .filter(([, v]) => v !== undefined && v !== null && v !== "")
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
      .join("&");
    if (query) url += `?${query}`;
  }

  const headers = {};
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (body && !isForm) headers["Content-Type"] = "application/json";

  const response = await fetch(url, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : null;

  if (!response.ok) {
    const message = (data && (data.detail || data.message)) || `Request failed (${response.status})`;
    throw new Error(typeof message === "string" ? message : JSON.stringify(message));
  }
  return data;
}

export const api = {
  login: (email, password) => request("/auth/login", { method: "POST", body: { email, password } }),
  register: (payload) => request("/auth/register", { method: "POST", body: payload }),

  listTasks: (filters) => request("/tasks", { params: filters }),
  createTask: (payload) => request("/tasks", { method: "POST", body: payload }),
  updateTaskStatus: (taskId, status) =>
    request(`/tasks/${taskId}/status`, { method: "PATCH", body: { status } }),

  listDocuments: () => request("/documents"),
  uploadDocument: (title, file) => {
    const form = new FormData();
    form.append("title", title);
    form.append("file", file);
    return request("/documents", { method: "POST", body: form, isForm: true });
  },

  search: (query, top_k = 5) => request("/search", { method: "POST", body: { query, top_k } }),

  analytics: () => request("/analytics"),
};

export default api;
