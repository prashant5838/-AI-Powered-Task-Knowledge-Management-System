import React, { useState } from "react";
import api from "../api";

export default function SemanticSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    try {
      const data = await api.search(query, 5);
      setResults(data.results);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h2>AI Knowledge Search</h2>
      <p className="muted">
        Searches document embeddings (TF-IDF vector space, cosine similarity) —
        not a plain keyword match.
      </p>
      <form onSubmit={handleSearch} style={{ display: "flex", gap: 10 }}>
        <input
          placeholder="Ask something, e.g. how do I reset my password?"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ marginBottom: 0 }}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Searching..." : "Search"}
        </button>
      </form>

      {error && <div className="error-text">{error}</div>}

      {results && (
        <div style={{ marginTop: 16 }}>
          {results.length === 0 ? (
            <p className="muted">No relevant results found in the knowledge base.</p>
          ) : (
            results.map((r, idx) => (
              <div className="search-result" key={idx}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <strong>{r.document_title}</strong>
                  <span className="score-tag">score: {r.score}</span>
                </div>
                <p className="muted">{r.chunk_text}</p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
