import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function Topbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <div className="topbar">
      <h1>AI Task & Knowledge Management</h1>
      <div className="right">
        {user && (
          <>
            <span className="muted">{user.name}</span>
            <span className="badge">{user.role}</span>
            <button className="secondary small" onClick={handleLogout}>
              Logout
            </button>
          </>
        )}
      </div>
    </div>
  );
}
