import React, { useCallback, useEffect, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";

export default function TaskList({ allowStatusUpdate = true }) {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadTasks = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const data = await api.listTasks({ status: statusFilter || undefined });
      setTasks(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  async function toggleStatus(task) {
    const nextStatus = task.status === "pending" ? "completed" : "pending";
    try {
      await api.updateTaskStatus(task.id, nextStatus);
      loadTasks();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="card">
      <h2>{user.role === "admin" ? "All Tasks" : "My Tasks"}</h2>

      <div style={{ maxWidth: 220 }}>
        <label>Filter by status</label>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All</option>
          <option value="pending">Pending</option>
          <option value="completed">Completed</option>
        </select>
      </div>

      {error && <div className="error-text">{error}</div>}
      {loading ? (
        <p className="muted">Loading tasks...</p>
      ) : tasks.length === 0 ? (
        <p className="muted">No tasks found.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Status</th>
              {allowStatusUpdate && <th></th>}
            </tr>
          </thead>
          <tbody>
            {tasks.map((t) => (
              <tr key={t.id}>
                <td>{t.title}</td>
                <td className="muted">{t.description || "—"}</td>
                <td>
                  <span className={`status-pill ${t.status}`}>{t.status}</span>
                </td>
                {allowStatusUpdate && (
                  <td>
                    <button className="small secondary" onClick={() => toggleStatus(t)}>
                      Mark {t.status === "pending" ? "Completed" : "Pending"}
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
