import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

// Guards a route: requires login, and optionally a specific role.
export default function ProtectedRoute({ children, requireRole }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;
  if (requireRole && user.role !== requireRole) {
    return <Navigate to={user.role === "admin" ? "/admin" : "/tasks"} replace />;
  }
  return children;
}
