import React, { useState } from "react";
import Topbar from "../components/Topbar";
import TaskList from "../components/TaskList";
import SemanticSearch from "../components/SemanticSearch";

const TABS = ["My Tasks", "Search Knowledge Base"];

export default function UserDashboard() {
  const [tab, setTab] = useState("My Tasks");

  return (
    <div className="app-shell">
      <Topbar />
      <div className="container">
        <div className="tabs">
          {TABS.map((t) => (
            <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>

        {tab === "My Tasks" && <TaskList allowStatusUpdate={true} />}
        {tab === "Search Knowledge Base" && <SemanticSearch />}
      </div>
    </div>
  );
}
