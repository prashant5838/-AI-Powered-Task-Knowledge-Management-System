import React, { useEffect, useState } from "react";
import Topbar from "../components/Topbar";
import TaskList from "../components/TaskList";
import SemanticSearch from "../components/SemanticSearch";
import api from "../api";

const TABS = ["Overview", "Documents", "Tasks", "Search"];

export default function AdminDashboard() {
  const [tab, setTab] = useState("Overview");

  return (
    <div className="app-shell">
      <Topbar />
      <div className="container">
        <div className="tabs">
          {TABS.map((t) => (
            <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>

        {tab === "Overview" && <AnalyticsPanel />}
        {tab === "Documents" && <DocumentsPanel />}
        {tab === "Tasks" && <TasksPanel />}
        {tab === "Search" && <SemanticSearch />}
      </div>
    </div>
  );
}

function AnalyticsPanel() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.analytics().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="card error-text">{error}</div>;
  if (!data) return <p className="muted">Loading analytics...</p>;

  const stats = [
    { label: "Total Tasks", value: data.total_tasks },
    { label: "Completed", value: data.completed_tasks },
    { label: "Pending", value: data.pending_tasks },
    { label: "Documents", value: data.total_documents },
  ];

  return (
    <>
      <div className="grid cols-4">
        {stats.map((s) => (
          <div className="card" key={s.label}>
            <h3>{s.label}</h3>
            <p className="stat-value">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <h2>Most Searched Queries</h2>
        {data.most_searched_queries.length === 0 ? (
          <p className="muted">No searches recorded yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Query</th>
                <th>Times searched</th>
              </tr>
            </thead>
            <tbody>
              {data.most_searched_queries.map((q) => (
                <tr key={q.query_text}>
                  <td>{q.query_text}</td>
                  <td>{q.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

function DocumentsPanel() {
  const [documents, setDocuments] = useState([]);
  const [title, setTitle] = useState("");
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [uploading, setUploading] = useState(false);

  async function loadDocuments() {
    try {
      setDocuments(await api.listDocuments());
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadDocuments();
  }, []);

  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    setError("");
    setSuccess("");
    try {
      await api.uploadDocument(title, file);
      setSuccess("Document uploaded and indexed for search.");
      setTitle("");
      setFile(null);
      e.target.reset();
      loadDocuments();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="grid cols-2">
      <div className="card">
        <h2>Upload Document (.txt)</h2>
        <form onSubmit={handleUpload}>
          <label>Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} required />
          <label>File</label>
          <input type="file" accept=".txt" onChange={(e) => setFile(e.target.files[0])} required />
          {error && <div className="error-text">{error}</div>}
          {success && <p className="muted" style={{ color: "var(--success)" }}>{success}</p>}
          <button type="submit" disabled={uploading}>
            {uploading ? "Uploading..." : "Upload & Index"}
          </button>
        </form>
      </div>

      <div className="card">
        <h2>Knowledge Base</h2>
        {documents.length === 0 ? (
          <p className="muted">No documents uploaded yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Filename</th>
                <th>Uploaded</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((d) => (
                <tr key={d.id}>
                  <td>{d.title}</td>
                  <td className="muted">{d.filename}</td>
                  <td className="muted">{new Date(d.uploaded_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function TasksPanel() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  async function handleCreate(e) {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      await api.createTask({
        title,
        description: description || undefined,
        assigned_to: assignedTo ? Number(assignedTo) : undefined,
      });
      setSuccess("Task created.");
      setTitle("");
      setDescription("");
      setAssignedTo("");
      setRefreshKey((k) => k + 1);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="grid cols-2">
      <div className="card">
        <h2>Create & Assign Task</h2>
        <form onSubmit={handleCreate}>
          <label>Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} required />
          <label>Description</label>
          <textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
          <label>Assign to (user ID)</label>
          <input
            value={assignedTo}
            onChange={(e) => setAssignedTo(e.target.value)}
            placeholder="e.g. 2"
          />
          {error && <div className="error-text">{error}</div>}
          {success && <p className="muted" style={{ color: "var(--success)" }}>{success}</p>}
          <button type="submit">Create Task</button>
        </form>
        <p className="muted">
          Tip: use POST /auth/register (admin token) to create user accounts and
          note their IDs before assigning tasks.
        </p>
      </div>

      <div key={refreshKey}>
        <TaskList allowStatusUpdate={true} />
      </div>
    </div>
  );
}
