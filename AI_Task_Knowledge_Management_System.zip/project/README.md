# AI-Powered Task & Knowledge Management System

An MVP where an **Admin** builds a knowledge base by uploading documents and
assigns tasks, and **Users** semantically search that knowledge base and
complete their assigned tasks.

---

## Tech Stack

| Layer          | Technology                                                   |
|----------------|---------------------------------------------------------------|
| Backend        | Python, FastAPI, SQLAlchemy ORM                               |
| Database       | MySQL (relational schema with FKs)                            |
| Auth           | JWT (python-jose) + bcrypt password hashing (passlib)          |
| AI / Search    | TF-IDF embeddings (scikit-learn, implemented from scratch) + FAISS (auto-detected) with a numpy cosine-similarity fallback |
| Frontend       | React.js (React Router, Context API for auth state, fetch-based API client) |

---

## Why TF-IDF instead of calling an LLM embedding API?

The assignment explicitly requires that **core logic be implemented**, not
just a wrapper around an external LLM API. `app/services/embedding_service.py`
implements the full text → vector pipeline ourselves:

1. **Chunking** – each document is split into overlapping ~120-word chunks
   (`chunk_text`) so long documents are searchable at a paragraph-like
   granularity.
2. **Vectorization** – a `TfidfVectorizer` (unigrams + bigrams, English stop
   words removed) is fit on every chunk in the knowledge base, producing a
   dense numeric vector per chunk that reflects term importance across the
   corpus. This is a genuine embedding technique, computed locally, with no
   network call.
3. **Vector storage & search** – `app/services/vector_store.py` normalizes
   vectors and does cosine-similarity search. If `faiss-cpu` is installed it
   automatically uses `faiss.IndexFlatIP` for the search; otherwise it falls
   back to an equivalent brute-force numpy implementation. Either way the
   calling code (`search_service.py`) is unaware of which backend is active.
4. The vectorizer is refit and the FAISS/numpy index rebuilt every time a
   new document is uploaded, so search always reflects the current KB.

**Swap-in point:** if you want transformer-based embeddings later (e.g.
`sentence-transformers`), you only need to change `EmbeddingService.fit` /
`embed` — nothing else in the app depends on how the vector is produced.

---

## Database Schema

```
roles (id, name)
users (id, name, email, hashed_password, role_id -> roles.id, created_at)
documents (id, title, filename, file_path, content_type, uploaded_by -> users.id, uploaded_at)
document_chunks (id, document_id -> documents.id, chunk_index, text, embedding [serialized vector])
tasks (id, title, description, status[pending|completed], assigned_to -> users.id, created_by -> users.id, created_at, updated_at)
activity_logs (id, user_id -> users.id, action, details, created_at)
search_queries (id, user_id -> users.id, query_text, created_at)
```

All foreign keys are enforced through SQLAlchemy relationships. `document_chunks`
and `search_queries` are supporting tables beyond the four mandatory ones,
needed to store embeddings per chunk and to power the "most searched
queries" analytic.

---

## Folder Structure

```
backend/
  app/
    main.py              # FastAPI app, CORS, startup seeding + index warm-up
    config.py            # env-driven settings
    database.py          # SQLAlchemy engine/session
    models.py             # ORM models (the schema above)
    schemas.py            # Pydantic request/response models
    security.py           # password hashing + JWT
    dependencies.py       # get_current_user, require_role (RBAC)
    seed.py               # bootstraps roles + default admin
    routers/
      auth.py             # /auth/login, /auth/register
      tasks.py            # /tasks (create, list+filter, update status)
      documents.py        # /documents (upload, list)
      search.py           # /search (semantic search)
      analytics.py        # /analytics
    services/
      embedding_service.py # TF-IDF embeddings + chunking (core AI logic)
      vector_store.py      # FAISS / numpy cosine-similarity index
      search_service.py    # orchestrates embedding + vector store + DB
      logging_service.py   # activity_logs writer
  requirements.txt
  .env.example
frontend/
  src/
    api.js                # fetch wrapper (JWT attached automatically)
    AuthContext.js         # login/logout state, persisted in localStorage
    App.js                 # routes + role-based redirects
    components/
      Topbar.js, ProtectedRoute.js, TaskList.js, SemanticSearch.js
    pages/
      Login.js, AdminDashboard.js, UserDashboard.js
sample_documents/          # sample .txt files to upload and try search with
docker-compose.yml          # one-command local MySQL instance
```

---

## Setup

### 1. Database (MySQL)

Either run MySQL yourself, or use the provided compose file:

```bash
docker compose up -d
```

This starts MySQL on `localhost:3306` with database `ai_task_kb`, user
`root`, password `password` (matches `.env.example`).

### 2. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # edit DB credentials if needed
uvicorn app.main:app --reload --port 8000
```

On first run, the app auto-creates all tables, seeds the `admin`/`user`
roles, and creates a default admin account:

```
email:    admin@example.com
password: Admin@123
```

(Change these via `DEFAULT_ADMIN_EMAIL` / `DEFAULT_ADMIN_PASSWORD` in `.env`.)

API docs (Swagger UI): **http://localhost:8000/docs**

### 3. Frontend

```bash
cd frontend
npm install
cp .env.example .env             # points to http://localhost:8000 by default
npm start
```

Visit **http://localhost:3000**, log in as the default admin, and:

1. Go to **Documents** → upload the sample `.txt` files from
   `sample_documents/` to build the knowledge base.
2. Go to **Tasks** → create a task (optionally assign it to a user's ID —
   use `POST /auth/register` from an admin session, or Swagger UI, to
   create a user account first and note their `id`).
3. Log in as that user and try **Search Knowledge Base** with a query like
   *"how do I reset my password"* — it will surface the relevant chunk
   from the KB via embeddings, not exact keyword matching.

---

## API Overview

| Endpoint                          | Method | Role        | Notes                                  |
|------------------------------------|--------|-------------|------------------------------------------|
| `/auth/login`                     | POST   | Public      | Returns JWT + role                        |
| `/auth/register`                  | POST   | Admin       | Create admin/user accounts                |
| `/tasks`                          | POST   | Admin       | Create & assign a task                    |
| `/tasks?status=&assigned_to=`      | GET    | Admin/User  | Dynamic filtering; users see only their own |
| `/tasks/{id}/status`               | PATCH  | Admin/User  | Pending ↔ Completed                        |
| `/documents`                       | POST   | Admin       | Upload `.txt`, auto-chunked & indexed      |
| `/documents`                       | GET    | Admin/User  | List KB documents                          |
| `/search`                          | POST   | Admin/User  | Semantic search, logs query for analytics  |
| `/analytics`                       | GET    | Admin       | Task counts, KB size, top search queries   |

Every login, task update, document upload, and search is written to
`activity_logs` (see `logging_service.log_activity`).

---

## RBAC Enforcement

- JWT payload carries `sub` (user id); role is looked up fresh from the DB
  on every request via `get_current_user`, so a role change takes effect
  immediately without needing to re-issue a token.
- `require_role(*roles)` is a dependency factory used to lock down routes
  (e.g. only `admin` can upload documents or create tasks).
- Regular users can only ever list/update **their own** tasks — this is
  enforced at the query level in `tasks.py`, not just hidden in the UI.

---

## Known Simplifications (MVP scope)

- Only `.txt` uploads are supported (PDF was listed as optional).
- TF-IDF is refit over the *entire* KB on every upload; fine for MVP scale,
  but a production version would use incremental indexing.
- The React app uses plain `fetch` + Context API rather than a heavier
  state-management library, since the requirement is clean, simple state
  management, not a specific library.
